var structT__DFP__OSI__MSGQ__CB__DATA =
[
    [ "p_OsiSpawn", "structT__DFP__OSI__MSGQ__CB__DATA.html#a708ccb8c878049e32de76968037772d2", null ]
];