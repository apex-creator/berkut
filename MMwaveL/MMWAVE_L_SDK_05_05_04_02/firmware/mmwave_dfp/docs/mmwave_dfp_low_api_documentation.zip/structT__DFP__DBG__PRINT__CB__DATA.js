var structT__DFP__DBG__PRINT__CB__DATA =
[
    [ "p_Print", "structT__DFP__DBG__PRINT__CB__DATA.html#a7ea5c208c867a6b3411ea2093f592e29", null ],
    [ "p_RfsdbgData", "structT__DFP__DBG__PRINT__CB__DATA.html#a1edb972188bc542c76ccb4d16c86d48c", null ]
];