var group__FECSSLIB__SENSOR__API =
[
    [ "Sensor device Driver API functions", "group__FECSSLIB__SENSOR__DRV__MODULE.html", "group__FECSSLIB__SENSOR__DRV__MODULE" ],
    [ "Sensor Driver API Patch functions", "group__FECSSLIB__SENSOR__DRV__PATCH.html", null ],
    [ "fe_sensChirpProfComnCfg_rom", "group__FECSSLIB__SENSOR__API.html#gad7c6ac0549c0ae529382e1260babc021", null ],
    [ "fe_sensChirpProfComnCfgGet_rom", "group__FECSSLIB__SENSOR__API.html#gaca4ff37d2267e289b09f9d49343c2123", null ],
    [ "fe_sensChirpProfTimeCfg_rom", "group__FECSSLIB__SENSOR__API.html#ga6e182229f6f1e8f082dad11be578526b", null ],
    [ "fe_sensChirpProfTimeCfgGet_rom", "group__FECSSLIB__SENSOR__API.html#gacf027ae6b2fb480d9a551c5fa0ab3fbe", null ],
    [ "fe_sensFrameCfg_rom", "group__FECSSLIB__SENSOR__API.html#ga802c571ffb8ae6b38642f4378e541ff9", null ],
    [ "fe_sensFrameCfgGet_rom", "group__FECSSLIB__SENSOR__API.html#ga9db1c07c26ceafa6460923ee8175fb27", null ],
    [ "fe_sensorStart_rom", "group__FECSSLIB__SENSOR__API.html#gacb3d6a9c708ea8ba100f5d9a0a15a329", null ],
    [ "fe_sensorStatusGet_rom", "group__FECSSLIB__SENSOR__API.html#ga1513f66d7e8d3e558578dcd278ddd4d6", null ],
    [ "fe_sensorStop_rom", "group__FECSSLIB__SENSOR__API.html#ga45a74007d6b40d1553ea95b5b945295c", null ],
    [ "fe_sensPerChirpCfg_rom", "group__FECSSLIB__SENSOR__API.html#ga514e53f2d7d7a3002dfb3504e1945408", null ],
    [ "fe_sensPerChirpCfgGet_rom", "group__FECSSLIB__SENSOR__API.html#gad7e6a8caf43f05bac94dd29ac6ad4f1c", null ],
    [ "fe_sensPerChirpCtrl_rom", "group__FECSSLIB__SENSOR__API.html#ga11990e5fba2cb6b710de1b8603805224", null ],
    [ "fe_sensPerChirpCtrlGet_rom", "group__FECSSLIB__SENSOR__API.html#ga5ac4bb13bb610eda3b16bd6305d01f13", null ]
];