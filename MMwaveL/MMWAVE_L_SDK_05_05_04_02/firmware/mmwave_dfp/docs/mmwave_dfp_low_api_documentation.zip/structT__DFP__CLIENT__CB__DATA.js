var structT__DFP__CLIENT__CB__DATA =
[
    [ "c_ApiDbglogEn", "structT__DFP__CLIENT__CB__DATA.html#a1b249f381c4320378000f45869a5bfb9", null ],
    [ "c_ApiErrorCheckDis", "structT__DFP__CLIENT__CB__DATA.html#ad1c49032df2b911cbcdb9c94f98333eb", null ],
    [ "c_DeviceType", "structT__DFP__CLIENT__CB__DATA.html#a2275f8a05af5b3197222e3ee771c5868", null ],
    [ "c_PlatformType", "structT__DFP__CLIENT__CB__DATA.html#a0e010dd0f802333ede4f7b8afe512acb", null ],
    [ "h_ApiRespTimeoutMs", "structT__DFP__CLIENT__CB__DATA.html#adc27e485a9e85a9f9d4568a08a63c5a2", null ],
    [ "h_Reserved1", "structT__DFP__CLIENT__CB__DATA.html#a36c615514a2a3aff8a42274d5118a752", null ],
    [ "z_ComIfCb", "structT__DFP__CLIENT__CB__DATA.html#a725b694d253fda1b296b19482fe7d3cf", null ],
    [ "z_DbgCb", "structT__DFP__CLIENT__CB__DATA.html#a65f72072420650bf4fc21b2aff229e88", null ],
    [ "z_OsiCb", "structT__DFP__CLIENT__CB__DATA.html#aab971abf661c200b3058aad6e413db7b", null ],
    [ "z_PltfCb", "structT__DFP__CLIENT__CB__DATA.html#a054010a58c204736937105dd6ad2fba3", null ]
];