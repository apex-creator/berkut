var structT__DFP__EXAMPLE__DEBUG__COUNTERS =
[
    [ "w_Burst", "structT__DFP__EXAMPLE__DEBUG__COUNTERS.html#a73e0721f619def65de7bd9a086026e8b", null ],
    [ "w_Chirp", "structT__DFP__EXAMPLE__DEBUG__COUNTERS.html#ac453bf8cc4c0e295b5e0429b67bbbf9e", null ],
    [ "w_Frame", "structT__DFP__EXAMPLE__DEBUG__COUNTERS.html#a2b16457ae70784054ccc952b549a2822", null ]
];