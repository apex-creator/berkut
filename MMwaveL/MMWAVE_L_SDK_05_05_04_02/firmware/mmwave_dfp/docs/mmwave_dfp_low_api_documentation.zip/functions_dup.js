var functions_dup =
[
    [ "b", "functions.html", null ],
    [ "c", "functions_c.html", null ],
    [ "h", "functions_h.html", null ],
    [ "p", "functions_p.html", null ],
    [ "r", "functions_r.html", null ],
    [ "w", "functions_w.html", null ],
    [ "x", "functions_x.html", null ],
    [ "z", "functions_z.html", null ]
];