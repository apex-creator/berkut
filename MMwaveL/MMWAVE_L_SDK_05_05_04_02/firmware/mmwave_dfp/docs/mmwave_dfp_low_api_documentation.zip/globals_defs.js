var globals_defs =
[
    [ "f", "globals_defs.html", null ],
    [ "m", "globals_defs_m.html", null ],
    [ "r", "globals_defs_r.html", null ]
];