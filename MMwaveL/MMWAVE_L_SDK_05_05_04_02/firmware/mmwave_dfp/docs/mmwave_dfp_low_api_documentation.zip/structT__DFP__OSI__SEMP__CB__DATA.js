var structT__DFP__OSI__SEMP__CB__DATA =
[
    [ "p_OsiSemCreate", "structT__DFP__OSI__SEMP__CB__DATA.html#a35f8500bfe94eb84216746e5ee1049c9", null ],
    [ "p_OsiSemDelete", "structT__DFP__OSI__SEMP__CB__DATA.html#aa649832d88d55a89d080ae47bd56c1bc", null ],
    [ "p_OsiSemSignal", "structT__DFP__OSI__SEMP__CB__DATA.html#a98a1bb17bbd18b257ba43d69e7298a22", null ],
    [ "p_OsiSemWait", "structT__DFP__OSI__SEMP__CB__DATA.html#a498362867ec359838bee1d8761564847", null ]
];