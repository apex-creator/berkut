var fe__registers_8h =
[
    [ "M_MEM16_READ", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#ga5e21b9833a70d260acc81306fe65b1f7", null ],
    [ "M_MEM16_WRITE", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#ga20e60c7107706e484b2cacbb6eaa8bdd", null ],
    [ "M_MEM32_READ", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#ga1e4bcecfc2fae128b6c8ccb87fbfdf13", null ],
    [ "M_MEM32_WRITE", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#ga4587d20687c711a1330d28f4c1673638", null ],
    [ "M_MEM8_READ", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#gac762352fa7477d22bfb856ae1e0c5392", null ],
    [ "M_MEM8_WRITE", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#ga38aa00ec6965834e97a05c6c99c18c0e", null ],
    [ "M_MEM_READ", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#gaf31407f076bb54ebf8f7a22aa0bbb27e", null ],
    [ "M_MEM_WRITE", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#gac69dc0c579908b1ab3a247b863203e44", null ],
    [ "M_REG32_READ", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#gae2e702af66bf86671aef81d3d0db7e68", null ],
    [ "M_REG32_SWRITE", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#gafc8b98a1b8ed15825f55e1905f2e96a4", null ],
    [ "M_REG32_WRITE", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#ga08f6138157c75dff91bcad3e15d01e93", null ],
    [ "M_REG_STRUCT_FIELD_READ", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#gab1e20c80c48a5cc099ab30a43b33ebdb", null ],
    [ "M_REG_STRUCT_FIELD_SWRITE", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#gad20c5a1f852b6c5368a56ce6fee74874", null ],
    [ "M_REG_STRUCT_FIELD_WRITE", "group__FECSSLIB__DEVICE__REGIF__MODULE.html#ga993f5c1a16df7f9904774805cdd77d3f", null ]
];