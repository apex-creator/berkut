var mmwavelink_8h =
[
    [ "M_RL_MMWAVELINK_VERSION", "group__MMWAVELINK__API.html#ga14bc7d03ee5c791c96087d99bcbb6873", null ],
    [ "M_RL_MMWAVELINK_VERSION_BUILD", "group__MMWAVELINK__API.html#gadd99e7855a0237a649122fce9ea0acd5", null ],
    [ "M_RL_MMWAVELINK_VERSION_DAY", "group__MMWAVELINK__API.html#ga20e4b283bcdcb696b39d848d0db3386f", null ],
    [ "M_RL_MMWAVELINK_VERSION_GEN", "group__MMWAVELINK__API.html#gaf06c76e2712091e98fb959b9f74558e7", null ],
    [ "M_RL_MMWAVELINK_VERSION_MAJOR", "group__MMWAVELINK__API.html#gadd975f3e0117192d530e71a1f73c4531", null ],
    [ "M_RL_MMWAVELINK_VERSION_MINOR", "group__MMWAVELINK__API.html#ga304fc28bcb4d00e14ebc1c074a5fabf4", null ],
    [ "M_RL_MMWAVELINK_VERSION_MONTH", "group__MMWAVELINK__API.html#gabe23482fbef9f670d8373fdd723570cd", null ],
    [ "M_RL_MMWAVELINK_VERSION_YEAR", "group__MMWAVELINK__API.html#ga671f88e8f7355741501bd30610e30584", null ],
    [ "rl_mmWaveLinkDeInit", "group__MMWAVELINK__API.html#gaf661252b4a52b2afdfe4566d10ac70a9", null ],
    [ "rl_mmWaveLinkInit", "group__MMWAVELINK__API.html#ga44927b170b3e1769a3d2fda4ddae0d8f", null ]
];