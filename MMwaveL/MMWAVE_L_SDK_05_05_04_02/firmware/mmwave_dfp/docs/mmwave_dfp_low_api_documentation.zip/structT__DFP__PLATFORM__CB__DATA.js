var structT__DFP__PLATFORM__CB__DATA =
[
    [ "p_Delay", "structT__DFP__PLATFORM__CB__DATA.html#ac737e7548eedc68d3d480b80c8cee0b8", null ],
    [ "p_DeRegisterIsr", "structT__DFP__PLATFORM__CB__DATA.html#ac9ebcc9244c2db35d5f4cc5b17916edb", null ],
    [ "p_EnterCriticalRegion", "structT__DFP__PLATFORM__CB__DATA.html#ae2703434e493cb0b5d38440e8a138d50", null ],
    [ "p_ExitCriticalRegion", "structT__DFP__PLATFORM__CB__DATA.html#ae969ca7dd08e0b2d85c24f1818c25f10", null ],
    [ "p_MaskIsr", "structT__DFP__PLATFORM__CB__DATA.html#a13c660ff375db007fe67794c93b0fd31", null ],
    [ "p_RegisterIsr", "structT__DFP__PLATFORM__CB__DATA.html#a72be5121bd1f203cdd380c6cfb70b9b8", null ],
    [ "p_TimeStamp", "structT__DFP__PLATFORM__CB__DATA.html#acb60f39c331b7a3a5e6021fee3413209", null ],
    [ "p_UnMaskIsr", "structT__DFP__PLATFORM__CB__DATA.html#a6fcf2cadfc81f2f057359e3005751392", null ],
    [ "w_TimeStampCounterMask", "structT__DFP__PLATFORM__CB__DATA.html#a7289f0fb0dc7777ad0ae33adecff42c1", null ]
];