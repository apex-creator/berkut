var dfp__common_8h =
[
    [ "M_DFP_ENTER_CRITICAL_REGION", "group__DFP__COMMON.html#ga4572ed78ab7c91e124100b2c67332b71", null ],
    [ "M_DFP_ENTER_SLEEP", "group__DFP__COMMON.html#ga5dc1f55b801b29ff209768cfb7f235c9", null ],
    [ "M_DFP_ENTER_SYSTEM_MODE", "group__DFP__COMMON.html#ga4369c7240251651410bedcdb7a35a159", null ],
    [ "M_DFP_ENTER_USER_MODE", "group__DFP__COMMON.html#ga37c93145564763b8be46cc92ef40a0c8", null ],
    [ "M_DFP_EXIT_CRITICAL_REGION", "group__DFP__COMMON.html#ga822f31ca09f17adac35ba57481bee0d2", null ],
    [ "M_DMLED_EXEC_M3_BIT_MASK", "group__DFP__COMMON.html#ga329525e16a2ed057ec39474002a39d90", null ],
    [ "M_DMLED_EXEC_M3_BIT_POS", "group__DFP__COMMON.html#ga89a1fb3fe7db330ee5879cfc52ac552a", null ],
    [ "M_DMLED_EXEC_R5_BIT_MASK", "group__DFP__COMMON.html#gab81ecdf3d4e02e42de1cbcd340c3e8ae", null ],
    [ "M_DMLED_EXEC_R5_BIT_POS", "group__DFP__COMMON.html#gac322489941318d436720e58a07dfc323", null ],
    [ "M_DMLED_STATUS_M3_BIT_MASK", "group__DFP__COMMON.html#ga97fb5cba2f850125f4850a0a97cef655", null ],
    [ "M_DMLED_STATUS_M3_BIT_POS", "group__DFP__COMMON.html#ga94f9a1f1feeb3a5c248fa7c456fc5287", null ],
    [ "M_DMLED_STATUS_R5_BIT_MASK", "group__DFP__COMMON.html#gad8d5941f1ce4e7c32da9ecd082a05b1c", null ],
    [ "M_DMLED_STATUS_R5_BIT_POS", "group__DFP__COMMON.html#ga022426999654bd7da596654e80c304eb", null ]
];