var structT__DFP__COMIF__CB__DATA =
[
    [ "p_ComIfClose", "structT__DFP__COMIF__CB__DATA.html#a18b61fa6d1253c68f178baccee3258fe", null ],
    [ "p_ComIfOpen", "structT__DFP__COMIF__CB__DATA.html#ad61696c0705eaea6a05188e874ee7a83", null ],
    [ "p_ComIfRead", "structT__DFP__COMIF__CB__DATA.html#aa16b8e5d3d302d1b28396322161b416d", null ],
    [ "p_ComIfWrite", "structT__DFP__COMIF__CB__DATA.html#aeba689b3f92fe59991a6278be7628ff3", null ]
];