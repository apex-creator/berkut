var globals_dup =
[
    [ "d", "globals.html", null ],
    [ "f", "globals_f.html", null ],
    [ "m", "globals_m.html", null ],
    [ "r", "globals_r.html", null ],
    [ "s", "globals_s.html", null ],
    [ "t", "globals_t.html", null ],
    [ "u", "globals_u.html", null ],
    [ "w", "globals_w.html", null ],
    [ "z", "globals_z.html", null ]
];