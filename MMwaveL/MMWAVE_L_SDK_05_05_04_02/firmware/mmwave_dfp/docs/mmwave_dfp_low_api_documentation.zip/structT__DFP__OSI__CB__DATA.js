var structT__DFP__OSI__CB__DATA =
[
    [ "z_Mutex", "structT__DFP__OSI__CB__DATA.html#a5d670b592998305d685c1b1a83942b51", null ],
    [ "z_Queue", "structT__DFP__OSI__CB__DATA.html#a0ba7b9fadff28373d78acc0c16efafc0", null ],
    [ "z_Semp", "structT__DFP__OSI__CB__DATA.html#a192b1a39889581f2579b104f2e1c66e7", null ]
];