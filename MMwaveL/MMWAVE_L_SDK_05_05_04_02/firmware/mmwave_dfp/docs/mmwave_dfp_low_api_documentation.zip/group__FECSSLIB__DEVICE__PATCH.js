var group__FECSSLIB__DEVICE__PATCH =
[
    [ "fe_fecssDevStatusGet_patch", "group__FECSSLIB__DEVICE__PATCH.html#ga63fbc6407c883022c976479082fbb030", null ]
];