var group__FECSSLIB__DRV__API =
[
    [ "FECSSLib Device Control driver API functions", "group__FECSSLIB__DEVICE__API.html", "group__FECSSLIB__DEVICE__API" ],
    [ "FECSSLib Sensor Control driver API functions", "group__FECSSLIB__SENSOR__API.html", "group__FECSSLIB__SENSOR__API" ],
    [ "FECSSLib RFS Control driver API functions", "group__FECSSLIB__RFS__API.html", "group__FECSSLIB__RFS__API" ],
    [ "FECSSLib ROM/PATCH functions mapping", "group__FECSSLIB__ROM__MAP.html", "group__FECSSLIB__ROM__MAP" ],
    [ "M_FE_FECSSLIB_VERSION", "group__FECSSLIB__DRV__API.html#gaa26ce0b15981ae95983e7767a29dcb16", null ],
    [ "M_FE_FECSSLIB_VERSION_BUILD", "group__FECSSLIB__DRV__API.html#ga3a530fc11b99b776a310df84cb53322d", null ],
    [ "M_FE_FECSSLIB_VERSION_DAY", "group__FECSSLIB__DRV__API.html#ga4668372efbae2a64b474339308fac197", null ],
    [ "M_FE_FECSSLIB_VERSION_GEN", "group__FECSSLIB__DRV__API.html#ga1f679d77d9636c9e48b06bbf25d4a6f2", null ],
    [ "M_FE_FECSSLIB_VERSION_MAJOR", "group__FECSSLIB__DRV__API.html#ga12febda650cc204f02493cc5fd535f82", null ],
    [ "M_FE_FECSSLIB_VERSION_MINOR", "group__FECSSLIB__DRV__API.html#ga3cb724738ebe5765a76a87e721718dd5", null ],
    [ "M_FE_FECSSLIB_VERSION_MONTH", "group__FECSSLIB__DRV__API.html#gae134669500d2cf697896c15e0e8e6248", null ],
    [ "M_FE_FECSSLIB_VERSION_YEAR", "group__FECSSLIB__DRV__API.html#ga038903d7e2e023c237ecc76cd200bdff", null ],
    [ "fe_fecssLibDeInit_rom", "group__FECSSLIB__DRV__API.html#gafc080e39e15c4005ae6a5ba0be025469", null ],
    [ "fe_fecssLibInit_rom", "group__FECSSLIB__DRV__API.html#ga5b2e5516380ebd1ce8f40b4ca97c8176", null ]
];