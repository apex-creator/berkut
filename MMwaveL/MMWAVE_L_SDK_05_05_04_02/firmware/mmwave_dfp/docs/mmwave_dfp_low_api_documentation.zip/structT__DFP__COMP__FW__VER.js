var structT__DFP__COMP__FW__VER =
[
    [ "c_BuildVerNum", "structT__DFP__COMP__FW__VER.html#ae1030c1d2a87fb601b6ef918297e0bd4", null ],
    [ "c_Date", "structT__DFP__COMP__FW__VER.html#ae7537686b8c757b4d3cb7d432d5b2e5f", null ],
    [ "c_GenVerNum", "structT__DFP__COMP__FW__VER.html#ae796ed8115f155db3df71750cd0ae6c0", null ],
    [ "c_MajorVerNum", "structT__DFP__COMP__FW__VER.html#ab1368ef25ad1858e5fc66f18b937f41d", null ],
    [ "c_MinorVerNum", "structT__DFP__COMP__FW__VER.html#ad18447bf7e37115aa149b8b9db9dccaa", null ],
    [ "c_Month", "structT__DFP__COMP__FW__VER.html#a1d4dbe558d36b2633d8d016ac0c3d5da", null ],
    [ "c_Reserved", "structT__DFP__COMP__FW__VER.html#a8cb7e44eb1c3f29be371c2ab8ab20d6b", null ],
    [ "c_Year", "structT__DFP__COMP__FW__VER.html#a6cd47f0b8b4a8d3260502a2b518234af", null ]
];