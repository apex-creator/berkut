var searchData=
[
  ['sint16_0',['SINT16',['../group__MMWAVE__DFP__DATA.html#ga431347dac407b6445c36d8bca5348a50',1,'dfp_datatypes.h']]],
  ['sint32_1',['SINT32',['../group__MMWAVE__DFP__DATA.html#ga5df4393f4806ad434ebdccdecd6fc697',1,'dfp_datatypes.h']]],
  ['sint64_2',['SINT64',['../group__MMWAVE__DFP__DATA.html#ga13560e5559ece1b20a3f8f520b47e706',1,'dfp_datatypes.h']]],
  ['sint8_3',['SINT8',['../group__MMWAVE__DFP__DATA.html#ga94d2d807f400cd04e10fa0ec0269947b',1,'dfp_datatypes.h']]]
];
