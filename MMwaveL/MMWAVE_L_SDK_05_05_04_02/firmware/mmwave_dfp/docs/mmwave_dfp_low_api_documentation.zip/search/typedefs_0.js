var searchData=
[
  ['double64_0',['DOUBLE64',['../group__MMWAVE__DFP__DATA.html#ga2e99f2d14a439426dd4ce274893d6818',1,'dfp_datatypes.h']]]
];
