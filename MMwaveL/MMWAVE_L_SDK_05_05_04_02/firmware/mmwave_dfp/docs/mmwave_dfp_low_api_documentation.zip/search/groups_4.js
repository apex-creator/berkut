var searchData=
[
  ['sensor_20device_20driver_20api_20functions_0',['Sensor device Driver API functions',['../group__FECSSLIB__SENSOR__DRV__MODULE.html',1,'']]],
  ['sensor_20driver_20api_20patch_20functions_1',['Sensor Driver API Patch functions',['../group__FECSSLIB__SENSOR__DRV__PATCH.html',1,'']]]
];
