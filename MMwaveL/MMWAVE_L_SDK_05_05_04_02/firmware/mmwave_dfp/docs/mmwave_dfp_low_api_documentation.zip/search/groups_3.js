var searchData=
[
  ['rfs_20command_20api_20functions_0',['RFS Command API functions',['../group__FECSSLIB__RFS__CMD__MODULE.html',1,'']]],
  ['rfs_20control_20driver_20api_20functions_1',['RFS control Driver API functions',['../group__FECSSLIB__RFS__DRV__MODULE.html',1,'']]]
];
