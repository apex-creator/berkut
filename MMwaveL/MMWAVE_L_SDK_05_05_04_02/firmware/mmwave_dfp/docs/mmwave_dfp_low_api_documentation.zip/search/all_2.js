var searchData=
[
  ['device_20interface_20and_20driver_20api_20functions_0',['Device Interface and Driver API functions',['../group__FECSSLIB__DEVICE__DRV__MODULE.html',1,'']]],
  ['device_20interface_20and_20driver_20api_20patch_20functions_1',['Device Interface and Driver API Patch functions',['../group__FECSSLIB__DEVICE__DRV__PATCH.html',1,'(Global Namespace)'],['../group__FECSSLIB__DEVICE__PATCH.html',1,'(Global Namespace)']]],
  ['device_20register_20interface_20driver_20functions_2',['Device Register Interface Driver functions',['../group__FECSSLIB__DEVICE__REGIF__MODULE.html',1,'']]],
  ['dfp_5fdatatypes_2eh_3',['dfp_datatypes.h',['../dfp__datatypes_8h.html',1,'']]],
  ['dfp_5fdevice_2eh_4',['dfp_device.h',['../dfp__device_8h.html',1,'']]],
  ['dfp_5fmonitor_2eh_5',['dfp_monitor.h',['../dfp__monitor_8h.html',1,'']]],
  ['dfp_5fsensor_2eh_6',['dfp_sensor.h',['../dfp__sensor_8h.html',1,'']]],
  ['dfp_5ftrace_2eh_7',['dfp_trace.h',['../dfp__trace_8h.html',1,'']]],
  ['dfp_5fusers_2eh_8',['dfp_users.h',['../dfp__users_8h.html',1,'']]],
  ['double64_9',['DOUBLE64',['../group__MMWAVE__DFP__DATA.html#ga2e99f2d14a439426dd4ce274893d6818',1,'dfp_datatypes.h']]]
];
