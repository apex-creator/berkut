var searchData=
[
  ['reg16_0',['REG16',['../group__MMWAVE__DFP__DATA.html#gad38871aa6ed824d2a4136d5adeb5ca03',1,'dfp_datatypes.h']]],
  ['reg32_1',['REG32',['../group__MMWAVE__DFP__DATA.html#ga6a97df0fb823209336fe33518dbb61ac',1,'dfp_datatypes.h']]],
  ['reg64_2',['REG64',['../group__MMWAVE__DFP__DATA.html#gaae2e45802a041f62e5095d4c355bea4c',1,'dfp_datatypes.h']]],
  ['reg8_3',['REG8',['../group__MMWAVE__DFP__DATA.html#ga7f410f2daa75337d3e25b0c9a567bf0f',1,'dfp_datatypes.h']]]
];
