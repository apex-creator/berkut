var globals_func =
[
    [ "f", "globals_func.html", null ],
    [ "r", "globals_func_r.html", null ],
    [ "s", "globals_func_s.html", null ]
];