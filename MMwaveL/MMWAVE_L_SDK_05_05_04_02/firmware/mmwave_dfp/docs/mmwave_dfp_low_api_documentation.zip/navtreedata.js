/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "mmWave DFP", "index.html", [
    [ "mmWave DFP 3.x (Device Firmware Package)", "index.html", [
      [ "Introduction", "index.html#dfp_intro_sec", [
        [ "mmWave DFP Block Diagram", "index.html#autotoc_md14", null ],
        [ "Supported mmWave Sensor Devices", "index.html#autotoc_md15", null ]
      ] ],
      [ "DFP Components", "index.html#dfp_components_sec", [
        [ "FECSS Library", "index.html#dfp_fecssLib_subsec", [
          [ "FECSS Library Block Diagram", "index.html#autotoc_md18", null ],
          [ "FECSS Library ROM/Patch Options", "index.html#autotoc_md19", null ],
          [ "FECSS Library Driver APIs", "index.html#autotoc_md20", null ]
        ] ],
        [ "RFS Firmware", "index.html#dfp_rfs_subsec", [
          [ "RFS Block Diagram", "index.html#autotoc_md21", null ],
          [ "RFS - FECSSLib IPC", "index.html#autotoc_md22", null ]
        ] ],
        [ "mmWaveLink", "index.html#dfp_mmwl_subsec", [
          [ "mmWaveLink Library Block Diagram", "index.html#autotoc_md25", null ],
          [ "mmWaveLink APIs", "index.html#autotoc_md26", null ]
        ] ]
      ] ],
      [ "DFP Interface and Porting", "index.html#dfp_interface_sec", null ],
      [ "DFP Deployment Model", "index.html#dfp_distr_sec", null ],
      [ "Device Reference Clock", "index.html#dev_ref_clk", null ],
      [ "API Documentation", "index.html#mmWaveLink", null ],
      [ "\"mmwave-dfp-low\" Folder Structure", "index.html#dfp_folder_sec", null ],
      [ "Build Options", "index.html#dfp_build_sec", null ],
      [ "DFP Examples", "index.html#dfp_example_sec", null ]
    ] ],
    [ "mmWaveLink 3.x API Documentation", "MMWAVE_LINK_DOC.html", [
      [ "mmWaveLink Interface and porting Details", "MMWAVE_LINK_DOC.html#autotoc_md458", null ],
      [ "mmWaveLink APIs", "MMWAVE_LINK_DOC.html#autotoc_md460", [
        [ "mmWaveLink Device Module APIs", "MMWAVE_LINK_DOC.html#autotoc_md466", null ],
        [ "mmWaveLink Sensor Module APIs", "MMWAVE_LINK_DOC.html#autotoc_md467", null ],
        [ "mmWaveLink Monitor Module APIs", "MMWAVE_LINK_DOC.html#autotoc_md468", null ],
        [ "References", "MMWAVE_LINK_DOC.html#autotoc_md469", null ]
      ] ],
      [ "API Programming Sequence", "MMWAVE_LINK_DOC.html#autotoc_md470", [
        [ "In-field Operation", "MMWAVE_LINK_DOC.html#autotoc_md471", null ],
        [ "Customer Factory Calibration", "MMWAVE_LINK_DOC.html#autotoc_md472", null ]
      ] ],
      [ "Frame, Burst and Chirp Timing Constraints", "MMWAVE_LINK_DOC.html#autotoc_md473", [
        [ "Burst Cycle Times", "MMWAVE_LINK_DOC.html#autotoc_md474", null ],
        [ "Frame Cycle Times", "MMWAVE_LINK_DOC.html#autotoc_md475", null ]
      ] ],
      [ "Calibration and Monitoring Timings", "MMWAVE_LINK_DOC.html#autotoc_md476", [
        [ "Factory Calibrations", "MMWAVE_LINK_DOC.html#autotoc_md477", null ],
        [ "Runtime Calibrations", "MMWAVE_LINK_DOC.html#autotoc_md478", null ],
        [ "Monitors", "MMWAVE_LINK_DOC.html#autotoc_md479", null ]
      ] ]
    ] ],
    [ "FECSSLib Drivers API Documentation", "md_E__TI_WORKAREA_MMWAVE_DFP_LOW_MMWL_Node_0_mmwave_dfp_low_docs_doxygen_source_fecsslib.html", [
      [ "FECSSLib Interface and porting Details", "md_E__TI_WORKAREA_MMWAVE_DFP_LOW_MMWL_Node_0_mmwave_dfp_low_docs_doxygen_source_fecsslib.html#autotoc_md459", null ],
      [ "FECSSLib Driver APIs", "md_E__TI_WORKAREA_MMWAVE_DFP_LOW_MMWL_Node_0_mmwave_dfp_low_docs_doxygen_source_fecsslib.html#autotoc_md461", [
        [ "FECSSLib Device Module Drivers", "md_E__TI_WORKAREA_MMWAVE_DFP_LOW_MMWL_Node_0_mmwave_dfp_low_docs_doxygen_source_fecsslib.html#autotoc_md462", null ],
        [ "FECSSLib Sensor Module Drivers", "md_E__TI_WORKAREA_MMWAVE_DFP_LOW_MMWL_Node_0_mmwave_dfp_low_docs_doxygen_source_fecsslib.html#autotoc_md463", null ],
        [ "FECSSLib RF Scripter Module Drivers", "md_E__TI_WORKAREA_MMWAVE_DFP_LOW_MMWL_Node_0_mmwave_dfp_low_docs_doxygen_source_fecsslib.html#autotoc_md464", null ],
        [ "References", "md_E__TI_WORKAREA_MMWAVE_DFP_LOW_MMWL_Node_0_mmwave_dfp_low_docs_doxygen_source_fecsslib.html#autotoc_md465", null ]
      ] ]
    ] ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"MMWAVE_LINK_DOC.html",
"group__FECSSLIB__DEVICE__REGIF__MODULE.html",
"group__FECSSLIB__ROM__MAP.html#gad116fd7fc4f14d44ac47b9b8567a408e",
"group__MMWAVE__DFP__INTERFACE.html#gac97788cfbd01a5c3a279b76fd649ee72",
"group__MMWL__MONITOR__API.html#gace2fac2465c6d0327d885014c4701d36",
"rlexample__txclpccal_8c.html#a7203b31c9bb4292045399b2614fca6dc",
"structT__FECRCM__REGS.html#a5ab4e3709a3768676d0984d510f8ce0f",
"structT__RL__API__FECSS__DEV__STS__RSP.html#a3ec8df9669f75f4989a514e6961fdaf8",
"structT__RL__API__MON__RX__HPF__DCSIG__RESULT.html#adad85885669e932d55697b63bec2a941",
"structT__TOPPRCM__REGS.html#a3855714678b2b00d964bc9dbce903823",
"unionU__CT__HPF__FAST__INIT__SYNTH__TIMING__1__REG.html#a868a06f8b1b2b8d677bc5122b994f51d",
"unionU__CT__PERCHIRP__PARAMETER__LEN1.html#a8cb9bb58bf7e7e996d381e67d23759ca",
"unionU__FECCTRL__FECSS__FORCEFCLKACTIVE.html",
"unionU__FECCTRL__HW__SPARE__RW1.html#a05d2223cd5868326f839e122b821adf6",
"unionU__FECRCM__IPCFGCLKGATE0.html#a5b414dea2a175edbc738a792a8d8b490",
"unionU__FT__PID.html#a0f67977921b80734c1c2ca14a0bf7eb4",
"unionU__TOPPRCM__DEBUG__MEM__PSCON__OVERRIDE__VAL__1.html#a1d8641915ad7752dae4455789ce2b64b",
"unionU__TOPPRCM__PMS__BGAP__DELAY1.html#a023cb8e59167fb27d6e3f41fa9c9c87f",
"unionU__TOPPRCM__PSCON__SRAM__LDO__WEAK__PROCESS.html#a062980eac509957148b75132d3eb8234",
"unionU__TOPPRCM__TOP__LDO__3318__CTRL__REG0.html#a8cb9bb58bf7e7e996d381e67d23759ca"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';