var modules =
[
    [ "mmWave DFP Standards Data Types", "group__MMWAVE__DFP__DATA.html", "group__MMWAVE__DFP__DATA" ],
    [ "mmWave DFP Debug Module", "group__MMWAVE__DFP__DEBUG.html", "group__MMWAVE__DFP__DEBUG" ],
    [ "mmWave DFP Interface Framework", "group__MMWAVE__DFP__INTERFACE.html", "group__MMWAVE__DFP__INTERFACE" ],
    [ "Device Interface and Driver API Patch functions", "group__FECSSLIB__DEVICE__PATCH.html", "group__FECSSLIB__DEVICE__PATCH" ],
    [ "FECSSLib Driver API functions", "group__FECSSLIB__DRV__API.html", "group__FECSSLIB__DRV__API" ],
    [ "mmWaveLink API functions", "group__MMWAVELINK__API.html", "group__MMWAVELINK__API" ],
    [ "mmWave DFP Example Functions", "group__MMWAVE__DFP__EXAMPLES.html", "group__MMWAVE__DFP__EXAMPLES" ]
];