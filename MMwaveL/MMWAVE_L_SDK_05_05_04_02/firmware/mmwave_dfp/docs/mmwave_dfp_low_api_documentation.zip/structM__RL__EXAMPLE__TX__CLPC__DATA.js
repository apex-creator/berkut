var structM__RL__EXAMPLE__TX__CLPC__DATA =
[
    [ "c_Reserved", "structM__RL__EXAMPLE__TX__CLPC__DATA.html#a8cb7e44eb1c3f29be371c2ab8ab20d6b", null ],
    [ "c_TxCalTempBinIndex", "structM__RL__EXAMPLE__TX__CLPC__DATA.html#a1ab505e32000180d5a608dfa5a9caddd", null ],
    [ "xh_LastCalTemp", "structM__RL__EXAMPLE__TX__CLPC__DATA.html#a16fa462152bbe6ddd3b6b8bbe90198e8", null ],
    [ "z_txRuntimeCalLut", "structM__RL__EXAMPLE__TX__CLPC__DATA.html#af60b8a666fa73cb484055342670b3943", null ]
];