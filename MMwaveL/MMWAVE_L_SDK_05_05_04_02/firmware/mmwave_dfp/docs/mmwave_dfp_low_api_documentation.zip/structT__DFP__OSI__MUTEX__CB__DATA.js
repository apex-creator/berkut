var structT__DFP__OSI__MUTEX__CB__DATA =
[
    [ "p_OsiMutexCreate", "structT__DFP__OSI__MUTEX__CB__DATA.html#a186d766eb3351a8559176727fd76c902", null ],
    [ "p_OsiMutexDelete", "structT__DFP__OSI__MUTEX__CB__DATA.html#a54c020468696a1843a83ca4762d69ce2", null ],
    [ "p_OsiMutexLock", "structT__DFP__OSI__MUTEX__CB__DATA.html#a10e9ad4a50cb6474905258c0379506ea", null ],
    [ "p_OsiMutexUnLock", "structT__DFP__OSI__MUTEX__CB__DATA.html#a97e9416366f9ea37f82df54b05d85104", null ]
];